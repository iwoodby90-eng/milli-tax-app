import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import {
  House, Wallet, Vault as VaultIcon, MapTrifold, Robot,
  List, SignOut, FileText, GearSix, PiggyBank, ChartLineUp, Receipt, Gift,
} from "@phosphor-icons/react";
import MilliLogo from "@/components/MilliLogo";
import { useState } from "react";

const primaryTabs = [
  { to: "/app", icon: House, label: "Home", end: true },
  { to: "/app/income", icon: Wallet, label: "Payouts" },
  { to: "/app/vault", icon: VaultIcon, label: "Vault" },
  { to: "/app/mileage", icon: MapTrifold, label: "Mileage" },
  { to: "/app/ai", icon: Robot, label: "Milli AI" },
];

const drawerNav = [
  ...primaryTabs,
  { to: "/app/expenses", icon: FileText, label: "Expenses" },
  { to: "/app/quarterly", icon: Receipt, label: "Quarterly Taxes" },
  { to: "/app/retirement", icon: PiggyBank, label: "Retirement" },
  { to: "/app/investing", icon: ChartLineUp, label: "Investing" },
  { to: "/app/reports", icon: FileText, label: "Reports" },
  { to: "/app/referral", icon: Gift, label: "Invite & Earn" },
  { to: "/app/settings", icon: GearSix, label: "Settings" },
];

function Tab({ item }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.to}
      end={item.end}
      className={({ isActive }) => `milli-tab ${isActive ? "is-active" : ""}`}
    >
      <Icon size={21} weight="duotone" />
      <span>{item.label}</span>
    </NavLink>
  );
}

export default function AppLayout({ children }) {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <div className="milli-shell">
      <header className="milli-topbar">
        <button className="milli-icon-button" onClick={() => setDrawerOpen(true)} aria-label="Open menu">
          <List size={23} weight="bold" />
        </button>
        <div className="milli-wordmark"><MilliLogo size={28} /><span>MILLI</span></div>
        <NavLink className="milli-icon-button" to="/app/settings" aria-label="Settings">
          <GearSix size={22} weight="duotone" />
        </NavLink>
      </header>

      <main className="milli-content">{children}</main>

      <nav className="milli-bottom-nav" aria-label="Primary navigation">
        {primaryTabs.map((item) => <Tab key={item.to} item={item} />)}
      </nav>

      {drawerOpen && (
        <div className="milli-drawer-backdrop" onClick={() => setDrawerOpen(false)}>
          <aside className="milli-drawer" onClick={(event) => event.stopPropagation()}>
            <div className="milli-drawer-brand"><MilliLogo size={34} /><span>MILLI</span></div>
            <nav>
              {drawerNav.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink key={`${item.to}-${item.label}`} to={item.to} end={item.end} onClick={() => setDrawerOpen(false)} className={({ isActive }) => `milli-drawer-link ${isActive ? "is-active" : ""}`}>
                    <Icon size={19} weight="duotone" />
                    <span>{item.label}</span>
                  </NavLink>
                );
              })}
            </nav>
            <button className="milli-signout" onClick={() => { logout(); navigate("/"); }}>
              <SignOut size={18} weight="bold" /> Sign Out
            </button>
          </aside>
        </div>
      )}
    </div>
  );
}
