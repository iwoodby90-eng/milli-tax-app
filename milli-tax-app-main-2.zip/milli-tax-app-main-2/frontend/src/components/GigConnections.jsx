import { useMemo, useState } from "react";
import { LinkSimple, CheckCircle, CaretRight, Lightning } from "@phosphor-icons/react";

const PLATFORMS = [
  { id: "uber", name: "Uber", mark: "U" },
  { id: "lyft", name: "Lyft", mark: "L" },
  { id: "doordash", name: "DoorDash", mark: "D" },
  { id: "spark", name: "Spark Driver", mark: "S" },
  { id: "flex", name: "Amazon Flex", mark: "A" },
  { id: "instacart", name: "Instacart", mark: "I" },
];

export default function GigConnections({ bankConnected = false, bankName = "your bank" }) {
  const [connected, setConnected] = useState(() => new Set());
  const connectedCount = connected.size;
  const status = useMemo(() => {
    if (connectedCount) return `${connectedCount} platform${connectedCount === 1 ? "" : "s"} connected`;
    if (bankConnected) return `Payout detection active via ${bankName}`;
    return "Connect a payout source";
  }, [bankConnected, bankName, connectedCount]);

  function toggle(id) {
    setConnected((current) => {
      const next = new Set(current);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  return (
    <section className="milli-card p-5 mb-4" data-testid="gig-connections">
      <div className="flex items-start justify-between gap-4 mb-5">
        <div>
          <div className="text-[11px] uppercase tracking-[0.22em] text-volt font-semibold">Gig Connections</div>
          <h3 className="text-xl font-semibold mt-1">Bring your work into Milli</h3>
          <p className="text-sm text-zinc-400 mt-1 max-w-xl">Connect supported payout feeds now. Offer intelligence will use direct integrations where available and a secure Share-to-Milli capture when a platform does not expose pre-acceptance offers.</p>
        </div>
        <div className="hidden sm:flex items-center gap-2 text-xs text-zinc-400 border border-white/10 rounded-full px-3 py-2 whitespace-nowrap">
          <Lightning size={14} className="text-volt" weight="fill" /> {status}
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {PLATFORMS.map((platform) => {
          const active = connected.has(platform.id);
          return (
            <button key={platform.id} onClick={() => toggle(platform.id)} className={`gig-source ${active ? "is-connected" : ""}`}>
              <span className="gig-source-mark">{platform.mark}</span>
              <span className="min-w-0 text-left">
                <strong>{platform.name}</strong>
                <small>{active ? "Connected" : "Connect"}</small>
              </span>
              {active ? <CheckCircle size={18} weight="fill" /> : <CaretRight size={16} />}
            </button>
          );
        })}
      </div>

      <div className="mt-4 pt-4 border-t border-white/[0.07] flex items-center gap-2 text-xs text-zinc-500">
        <LinkSimple size={15} className="text-volt" /> Accepted-trip and payout data can sync automatically. Pre-offer capture depends on each platform's permitted integration access.
      </div>
    </section>
  );
}
